#include <iostream>
using namespace std;

class Node {
public:
	int data;
	Node* next;
	Node(int value) { data = value; next = nullptr; }
};

class LinkedList {
private:
	Node* head;
public:
	LinkedList() { head = nullptr; }

	void insertAtPosition(int value, int pos) {
		Node* newNode = new Node(value);
		if (pos == 1) {
			newNode->next = head;
			head = newNode;
			return;
		}
		Node* temp = head;
		for (int i = 1; temp != nullptr && i < pos - 1; i++) {
			temp = temp->next;
		}
		if (temp == nullptr) {
			cout << "Position out of range\n";
			delete newNode;
			return;
		}
		newNode->next = temp->next;
		temp->next = newNode;
	}

	void deleteAtPosition(int pos) {
		if (head == nullptr) return;
		if (pos == 1) {
			Node* temp = head;
			head = head->next;
			delete temp;
			return;
		}
		Node* temp = head;
		for (int i = 1; temp != nullptr && i < pos - 1; i++) {
			temp = temp->next;
		}
		if (temp == nullptr || temp->next == nullptr) {
			cout << "Position out of range\n";
			return;
		}
		Node* nodeToDelete = temp->next;
		temp->next = temp->next->next;
		delete nodeToDelete;
	}

	void search(int value) {
		Node* temp = head;
		int pos = 1;
		while (temp != nullptr) {
			if (temp->data == value) {
				cout << "Found at position " << pos << endl;
				return;
			}
			temp = temp->next;
			pos++;
		}
		cout << "Not found\n";
	}

	void countNodes() {
		Node* temp = head;
		int count = 0;
		while (temp != nullptr) {
			count++;
			temp = temp->next;
		}
		cout << "Total nodes: " << count << endl;
	}

	void display() {
		Node* temp = head;
		while (temp != nullptr) {
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
	}
};

int main() {
	LinkedList list;
	int choice, value, pos;

	do {
		cout << "\nMenu:\n";
		cout << "1. Insert at position\n";
		cout << "2. Delete at position\n";
		cout << "3. Search element\n";
		cout << "4. Count nodes\n";
		cout << "5. Display list\n";
		cout << "6. Exit\n";
		cout << "Enter choice: ";
		cin >> choice;

		switch (choice) {
		case 1: cout << "Enter value and position: ";
			cin >> value >> pos;
			list.insertAtPosition(value, pos);
			break;
		case 2: cout << "Enter position: ";
			cin >> pos;
			list.deleteAtPosition(pos);
			break;
		case 3: cout << "Enter value to search: ";
			cin >> value;
			list.search(value);
			break;
		case 4: list.countNodes(); break;
		case 5: list.display(); break;
		}
	} while (choice != 6);

	return 0;
}
