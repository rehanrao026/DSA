#include <iostream>
#include <string>
using namespace std;


class Node {
public:
	string name;
	Node* next;

	Node(string patientName) {
		name = patientName;
		next = nullptr;
	}
};

class HospitalQueue {
private:
	Node* head;
public:
	HospitalQueue() { head = nullptr; }

	// Add patient at end
	void addPatient(string name) {
		Node* newNode = new Node(name);
		if (head == nullptr) {
			head = newNode;
			return;
		}
		Node* temp = head;
		while (temp->next != nullptr) {
			temp = temp->next;
		}
		temp->next = newNode;
	}

	// Remove patient by name
	void removePatient(string name) {
		if (head == nullptr) return;

		if (head->name == name) {
			Node* temp = head;
			head = head->next;
			delete temp;
			cout << "Patient " << name << " removed from queue.\n";
			return;
		}

		Node* temp = head;
		while (temp->next != nullptr && temp->next->name != name) {
			temp = temp->next;
		}

		if (temp->next != nullptr) {
			Node* nodeToDelete = temp->next;
			temp->next = temp->next->next;
			delete nodeToDelete;
			cout << "Patient " << name << " removed from queue.\n";
		}
		else {
			cout << "Patient " << name << " not found.\n";
		}
	}

	// Display all patients
	void displayQueue() {
		if (head == nullptr) {
			cout << "Queue is empty.\n";
			return;
		}
		Node* temp = head;
		cout << "Current patients in queue: ";
		while (temp != nullptr) {
			cout << temp->name << " ";
			temp = temp->next;
		}
		cout << endl;
	}

	// Count patients
	void countPatients() {
		int count = 0;
		Node* temp = head;
		while (temp != nullptr) {
			count++;
			temp = temp->next;
		}
		cout << "Total patients in queue: " << count << endl;
	}
};

int main() {
	HospitalQueue queue;

	
	queue.addPatient("Ali");
	queue.addPatient("Sara");
	queue.addPatient("Ahmed");

	queue.displayQueue();       
	queue.countPatients();      /

	queue.removePatient("Sara");
	queue.displayQueue();       
	queue.countPatients();      

	queue.removePatient("Zara"); 

	return 0;
}
