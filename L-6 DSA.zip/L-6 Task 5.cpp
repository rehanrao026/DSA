#include <iostream>
#include <string>
using namespace std;

class Node {
public:
	string name;
	int priority; // 1 = research, 2 = assignment, 3 = casual
	Node* next;

	Node(string n, int p) {
		name = n;
		priority = p;
		next = nullptr;
	}
};

class ReservationQueue {
private:
	Node* head;
public:
	ReservationQueue() { head = nullptr; }

	// Add student with priority
	void addStudent(string name, int priority) {
		Node* newNode = new Node(name, priority);

		// If empty or higher priority than head
		if (head == nullptr || priority < head->priority) {
			newNode->next = head;
			head = newNode;
			return;
		}

		Node* temp = head;
		while (temp->next != nullptr && temp->next->priority <= priority) {
			temp = temp->next;
		}
		newNode->next = temp->next;
		temp->next = newNode;
	}

	// Remove student by name
	void removeStudent(string name) {
		if (head == nullptr) return;

		if (head->name == name) {
			Node* temp = head;
			head = head->next;
			delete temp;
			cout << "Removed " << name << " from queue.\n";
			return;
		}

		Node* temp = head;
		while (temp->next != nullptr && temp->next->name != name) {
			temp = temp->next;
		}

		if (temp->next != nullptr) {
			Node* toDelete = temp->next;
			temp->next = temp->next->next;
			delete toDelete;
			cout << "Removed " << name << " from queue.\n";
		}
		else {
			cout << "Student " << name << " not found.\n";
		}
	}

	// Update priority
	void updatePriority(string name, int newPriority) {
		removeStudent(name);
		addStudent(name, newPriority);
		cout << "Updated " << name << "'s priority.\n";
	}

	// Display queue
	void displayQueue() {
		if (head == nullptr) {
			cout << "Queue is empty.\n";
			return;
		}
		Node* temp = head;
		cout << "Reservation list: ";
		while (temp != nullptr) {
			cout << "[" << temp->name << ", P" << temp->priority << "] ";
			temp = temp->next;
		}
		cout << endl;
	}

	// Count students
	void countStudents() {
		int count = 0;
		Node* temp = head;
		while (temp != nullptr) {
			count++;
			temp = temp->next;
		}
		cout << "Total students in queue: " << count << endl;
	}

	// Remove front student (book returned)
	void bookReturned() {
		if (head == nullptr) {
			cout << "No reservations.\n";
			return;
		}
		Node* temp = head;
		cout << "Book returned to " << temp->name << ".\n";
		head = head->next;
		delete temp;
	}
};

// Driver code
int main() {
	ReservationQueue book1, book2;

	// Sample data
	book1.addStudent("Ali", 2);
	book1.addStudent("Sara", 1);
	book1.addStudent("Ahmed", 3);

	book2.addStudent("Zara", 2);
	book2.addStudent("Bilal", 1);

	cout << "\nBook 1 Queue:\n";
	book1.displayQueue();
	book1.countStudents();

	cout << "\nBook 2 Queue:\n";
	book2.displayQueue();
	book2.countStudents();

	// Update priority
	book1.updatePriority("Ahmed", 1);
	book1.displayQueue();

	// Cancel reservation
	book2.removeStudent("Zara");
	book2.displayQueue();

	// Book returned
	book1.bookReturned();
	book1.displayQueue();

	return 0;
}