#include <iostream>
using namespace std;


class Node {
public:
	int data;
	Node* next;

	Node(int value) {
		data = value;
		next = nullptr;
	}
};

class LinkedList {
private:
	Node* head; 

public:
	LinkedList() {
		head = nullptr;  


	void insertAtBeginning(int value) {
		Node* newNode = new Node(value);
		newNode->next = head;
		head = newNode;
	}

	void insertAtEnd(int value) {
		Node* newNode = new Node(value);
		if (head == nullptr) {
			head = newNode;
			return;
		}
		Node* temp = head;
		while (temp->next != nullptr) {
			temp = temp->next;
		}
		temp->next = newNode;
	}


	void deleteByValue(int value) {
		if (head == nullptr) return;


		if (head->data == value) {
			Node* temp = head;
			head = head->next;
			delete temp;
			return;
		}

		Node* temp = head;
		while (temp->next != nullptr && temp->next->data != value) {
			temp = temp->next;
		}

		if (temp->next != nullptr) {
			Node* nodeToDelete = temp->next;
			temp->next = temp->next->next;
			delete nodeToDelete;
		}
	}

	void display() {
		Node* temp = head;
		while (temp != nullptr) {
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
	}
};

// Driver code
int main() {
	LinkedList list;

	list.insertAtBeginning(10);
	list.insertAtEnd(20);
	list.insertAtEnd(30);
	list.insertAtBeginning(5);

	cout << "List after insertions: ";
	list.display();  

	list.deleteByValue(20);
	cout << "List after deleting 20: ";
	list.display();  

	return 0;
}
