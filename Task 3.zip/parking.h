#ifndef PARKING_H
#define PARKING_H

#include <iostream>
#include <string>
using namespace std;

class myCarStack{
    string arr[8];
    int top;

public:
    myCarStack(){ top=-1; }

    bool isEmpty(){ return top==-1; }
    bool isFull(){ return top==7; }

    void push(string car){
        if(isFull()){
            cout<<"Parking Full\n";
            return;
        }
        arr[++top]=car;
        cout<<"Car Parked\n";
    }

    string pop(){
        if(isEmpty()) return "";
        return arr[top--];
    }

    int count(){
        return top+1;
    }

    void display(){
        if(isEmpty()){
            cout<<"Parking Empty\n";
            return;
        }

        cout<<"Cars in Parking:\n";
        for(int i=top;i>=0;i--)
            cout<<arr[i]<<endl;
    }

    bool search(string car){
        for(int i=0;i<=top;i++)
            if(arr[i]==car)
                return true;
        return false;
    }

    void removeCar(string car){
        if(isEmpty()){
            cout<<"Parking Empty\n";
            return;
        }

        myCarStack temp;
        bool found=false;

        while(!isEmpty()){
            string c=pop();

            if(c==car){
                cout<<"Car Removed\n";
                found=true;
                break;
            }

            temp.push(c);
        }

        while(!temp.isEmpty())
            push(temp.pop());

        if(!found)
            cout<<"Car Not Found\n";
    }
};

#endif
