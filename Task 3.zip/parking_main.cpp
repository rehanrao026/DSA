#include <iostream>
#include "parking.h"
using namespace std;

int main(){

    myCarStack parking;
    int choice;
    string car;

    do{

        cout<<"\n1 Park Car\n";
        cout<<"2 Remove Car\n";
        cout<<"3 Show Parked Cars\n";
        cout<<"4 Total Cars\n";
        cout<<"5 Search Car\n";
        cout<<"6 Exit\n";

        cout<<"Choice: ";
        cin>>choice;

        switch(choice){

        case 1:
            cout<<"Enter Car Number: ";
            cin>>car;
            parking.push(car);
            break;

        case 2:
            cout<<"Enter Car Number: ";
            cin>>car;
            parking.removeCar(car);
            break;

        case 3:
            parking.display();
            break;

        case 4:
            cout<<"Total Cars: "<<parking.count()<<endl;
            break;

        case 5:
            cout<<"Enter Car Number: ";
            cin>>car;
            if(parking.search(car))
                cout<<"Car Found\n";
            else
                cout<<"Car Not Found\n";
            break;

        case 6:
            cout<<"Exit\n";
            break;

        default:
            cout<<"Invalid Choice\n";
        }

    }while(choice!=6);

    return 0;
}
