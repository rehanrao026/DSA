#ifndef EDITOR_H
#define EDITOR_H

#include <stack>
#include <string>
using namespace std;

class TextEditor{

    stack<string> undoStack;
    stack<string> redoStack;
    string text;

public:

    void typeChar(char ch){
        undoStack.push(text);
        text+=ch;
        while(!redoStack.empty())
            redoStack.pop();
    }

    void deleteChar(){
        if(text.length()>0){
            undoStack.push(text);
            text.pop_back();
            while(!redoStack.empty())
                redoStack.pop();
        }
    }

    void undo(){
        if(!undoStack.empty()){
            redoStack.push(text);
            text=undoStack.top();
            undoStack.pop();
        }
    }

    void redo(){
        if(!redoStack.empty()){
            undoStack.push(text);
            text=redoStack.top();
            redoStack.pop();
        }
    }

    string getText(){
        return text;
    }
};

#endif
