#include <iostream>
#include "editor.h"
using namespace std;

int main(){

    TextEditor editor;
    int choice;
    char ch;

    do{

        cout<<"\nCurrent Text: "<<editor.getText()<<endl;

        cout<<"\n1 Type Character\n";
        cout<<"2 Delete Character\n";
        cout<<"3 Undo\n";
        cout<<"4 Redo\n";
        cout<<"5 Exit\n";

        cout<<"Choice: ";
        cin>>choice;

        switch(choice){

        case 1:
            cout<<"Enter character: ";
            cin>>ch;
            editor.typeChar(ch);
            break;

        case 2:
            editor.deleteChar();
            break;

        case 3:
            editor.undo();
            break;

        case 4:
            editor.redo();
            break;

        case 5:
            cout<<"Exit\n";
            break;

        default:
            cout<<"Invalid Choice\n";
        }

    }while(choice!=5);

    return 0;
}
